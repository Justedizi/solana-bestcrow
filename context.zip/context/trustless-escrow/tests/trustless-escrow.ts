import * as anchor from "@coral-xyz/anchor";
import { Program } from "@coral-xyz/anchor";
import { TrustlessEscrow } from "../target/types/trustless_escrow";
import {
  PublicKey,
  Keypair,
  SystemProgram,
  SYSVAR_RENT_PUBKEY,
} from "@solana/web3.js";
import {
  TOKEN_PROGRAM_ID,
  createMint,
  createAccount,
  mintTo,
  getAccount,
} from "@solana/spl-token";
import { assert } from "chai";

describe("trustless-escrow", () => {
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.TrustlessEscrow as Program<TrustlessEscrow>;

  // Keypairs
  const client = (provider.wallet as anchor.Wallet).payer;
  const freelancer = Keypair.generate();
  const arbitrator = Keypair.generate();

  // Token accounts
  let usdcMint: PublicKey;
  let clientTokenAccount: PublicKey;
  let freelancerTokenAccount: PublicKey;

  // PDAs
  let escrowPDA: PublicKey;
  let escrowBump: number;
  let vaultPDA: PublicKey;
  let milestonePDA: PublicKey;

  const ESCROW_SEED = Buffer.from("escrow");
  const VAULT_SEED = Buffer.from("vault");
  const MILESTONE_SEED = Buffer.from("milestone");

  const totalAmount = new anchor.BN(1_000_000); // 1 USDC (6 decimals)
  const milestoneCount = 3;

  before(async () => {
    // Wait for airdrops
    await new Promise((resolve) => setTimeout(resolve, 2000));

    // Fund freelancer and arbitrator from provider wallet
    await provider.connection.sendTransaction(
      new anchor.web3.Transaction().add(
        anchor.web3.SystemProgram.transfer({
          fromPubkey: provider.wallet.publicKey,
          toPubkey: freelancer.publicKey,
          lamports: 0.1 * anchor.web3.LAMPORTS_PER_SOL,
        })
      ),
      [(provider.wallet as anchor.Wallet).payer]
    );

    await provider.connection.sendTransaction(
      new anchor.web3.Transaction().add(
        anchor.web3.SystemProgram.transfer({
          fromPubkey: provider.wallet.publicKey,
          toPubkey: arbitrator.publicKey,
          lamports: 0.1 * anchor.web3.LAMPORTS_PER_SOL,
        })
      ),
      [(provider.wallet as anchor.Wallet).payer]
    );

    // Wait for transfers to confirm
    await new Promise((resolve) => setTimeout(resolve, 3000));

    // Create USDC mint
    usdcMint = await createMint(
      provider.connection,
      client,
      client.publicKey,
      null,
      6
    );

    // Create token accounts
    clientTokenAccount = await createAccount(
      provider.connection,
      client,
      usdcMint,
      client.publicKey
    );

    freelancerTokenAccount = await createAccount(
      provider.connection,
      freelancer,
      usdcMint,
      freelancer.publicKey
    );

    // Mint USDC to client
    await mintTo(
      provider.connection,
      client,
      usdcMint,
      clientTokenAccount,
      client,
      2_000_000 // 2 USDC
    );

    // Derive PDAs
    [escrowPDA, escrowBump] = PublicKey.findProgramAddressSync(
      [ESCROW_SEED, client.publicKey.toBuffer()],
      program.programId
    );

    [vaultPDA] = PublicKey.findProgramAddressSync(
      [VAULT_SEED, escrowPDA.toBuffer()],
      program.programId
    );

    [milestonePDA] = PublicKey.findProgramAddressSync(
      [MILESTONE_SEED, escrowPDA.toBuffer(), Buffer.from([0])],
      program.programId
    );
  });

  // ── Test 1: Initialize Escrow ──
  it("Initializes escrow and locks USDC in vault", async () => {
    await program.methods
      .initialize(
        freelancer.publicKey,
        arbitrator.publicKey,
        totalAmount,
        milestoneCount
      )
      .accounts({
        client: client.publicKey,
        escrow: escrowPDA,
        vault: vaultPDA,
        clientTokenAccount,
        usdcMint,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
        rent: SYSVAR_RENT_PUBKEY,
      })
      .signers([client])
      .rpc();

    // Verify escrow state
    const escrow = await program.account.escrowAccount.fetch(escrowPDA);
    assert.equal(escrow.client.toString(), client.publicKey.toString());
    assert.equal(escrow.freelancer.toString(), freelancer.publicKey.toString());
    assert.equal(escrow.totalAmount.toString(), totalAmount.toString());
    assert.equal(escrow.milestoneCount, milestoneCount);
    assert.deepEqual(escrow.status, { open: {} });

    // Verify vault received funds
    const vault = await getAccount(provider.connection, vaultPDA);
    assert.equal(vault.amount.toString(), totalAmount.toString());

    console.log("✅ Escrow initialized. USDC locked in vault.");
  });

  // ── Test 2: Create Milestone ──
  it("Creates a milestone", async () => {
    const milestoneAmount = new anchor.BN(333_333);
    const description = "Design the landing page wireframes";

    await program.methods
      .createMilestone(0, milestoneAmount, description)
      .accounts({
        client: client.publicKey,
        escrow: escrowPDA,
        milestone: milestonePDA,
        systemProgram: SystemProgram.programId,
      })
      .signers([client])
      .rpc();

    const milestone = await program.account.milestoneAccount.fetch(milestonePDA);
    assert.equal(milestone.index, 0);
    assert.equal(milestone.amount.toString(), milestoneAmount.toString());
    assert.equal(milestone.description, description);
    assert.deepEqual(milestone.status, { pending: {} });

    console.log("✅ Milestone 0 created.");
  });

  // ── Test 3: Accept Job ──
  it("Freelancer accepts the job", async () => {
    await program.methods
      .acceptJob()
      .accounts({
        freelancer: freelancer.publicKey,
        escrow: escrowPDA,
        systemProgram: SystemProgram.programId,
      })
      .signers([freelancer])
      .rpc();

    const escrow = await program.account.escrowAccount.fetch(escrowPDA);
    assert.deepEqual(escrow.status, { inProgress: {} });

    console.log("✅ Job accepted by freelancer.");
  });

  // ── Test 4: Submit and Approve Milestone ──
  it("Freelancer submits milestone and client approves, releasing payment", async () => {
    // Submit milestone
    await program.methods
      .submitMilestone(0)
      .accounts({
        freelancer: freelancer.publicKey,
        escrow: escrowPDA,
        milestone: milestonePDA,
        systemProgram: SystemProgram.programId,
      })
      .signers([freelancer])
      .rpc();

    let milestone = await program.account.milestoneAccount.fetch(milestonePDA);
    assert.deepEqual(milestone.status, { submitted: {} });
    console.log("✅ Milestone submitted by freelancer.");

    // Approve milestone
    await program.methods
      .approveMilestone(0)
      .accounts({
        client: client.publicKey,
        escrow: escrowPDA,
        milestone: milestonePDA,
        vault: vaultPDA,
        freelancerTokenAccount,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .signers([client])
      .rpc();

    milestone = await program.account.milestoneAccount.fetch(milestonePDA);
    assert.deepEqual(milestone.status, { approved: {} });

    const escrow = await program.account.escrowAccount.fetch(escrowPDA);
    assert.equal(escrow.milestonesApproved, 1);

    console.log("✅ Milestone approved. Payment released to freelancer.");
  });

  // ── Test 5: Reject Milestone ──
  it("Client rejects a milestone and sends it back for revision", async () => {
    // Create milestone 1
    const [milestone1PDA] = PublicKey.findProgramAddressSync(
      [MILESTONE_SEED, escrowPDA.toBuffer(), Buffer.from([1])],
      program.programId
    );

    await program.methods
      .createMilestone(1, new anchor.BN(333_333), "Build the homepage")
      .accounts({
        client: client.publicKey,
        escrow: escrowPDA,
        milestone: milestone1PDA,
        systemProgram: SystemProgram.programId,
      })
      .signers([client])
      .rpc();

    // Submit milestone 1
    await program.methods
      .submitMilestone(1)
      .accounts({
        freelancer: freelancer.publicKey,
        escrow: escrowPDA,
        milestone: milestone1PDA,
        systemProgram: SystemProgram.programId,
      })
      .signers([freelancer])
      .rpc();

    // Reject milestone 1
    await program.methods
      .rejectMilestone(1)
      .accounts({
        client: client.publicKey,
        escrow: escrowPDA,
        milestone: milestone1PDA,
        systemProgram: SystemProgram.programId,
      })
      .signers([client])
      .rpc();

    const milestone = await program.account.milestoneAccount.fetch(milestone1PDA);
    assert.deepEqual(milestone.status, { inProgress: {} });

    console.log("✅ Milestone rejected. Sent back for revision.");
  });
});
