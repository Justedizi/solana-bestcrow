// Tests will be written after all instructions compile cleanly
