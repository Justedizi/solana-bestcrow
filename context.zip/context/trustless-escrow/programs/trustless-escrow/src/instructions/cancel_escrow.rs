use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(ctx: Context<CancelEscrow>) -> Result<()> {
    let escrow = &mut ctx.accounts.escrow;

    // Only the client can cancel
    require!(
        ctx.accounts.client.key() == escrow.client,
        EscrowError::UnauthorizedClient
    );

    // Escrow must be Open or InProgress
    require!(
        escrow.status == EscrowStatus::Open
            || escrow.status == EscrowStatus::InProgress,
        EscrowError::InvalidEscrowStatus
    );

    // Locked permanently once 4 or more milestones approved
    // Logic: if client approved 4 milestones, work is clearly good
    // enough — no cancellation allowed beyond this point
    require!(
        escrow.milestones_approved < 4,
        EscrowError::CannotCancelAfterApproval
    );

    // Calculate remaining refund amount
    // Already paid milestones are excluded from refund
    let amount_per_milestone = escrow.total_amount
        .checked_div(escrow.milestone_count as u64)
        .unwrap();

    let already_paid = amount_per_milestone
        .checked_mul(escrow.milestones_approved as u64)
        .unwrap();

    let refund_amount = escrow.total_amount
        .checked_sub(already_paid)
        .unwrap();

    // Refund remaining locked USDC back to client
    let seeds = &[
        ESCROW_SEED,
        escrow.client.as_ref(),
        &[escrow.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    let transfer_ctx = CpiContext::new_with_signer(
        ctx.accounts.token_program.key(),
        Transfer {
            from: ctx.accounts.vault.to_account_info(),
            to: ctx.accounts.client_token_account.to_account_info(),
            authority: escrow.to_account_info(),
        },
        signer_seeds,
    );
    token::transfer(transfer_ctx, refund_amount)?;

    // Mark escrow as cancelled
    escrow.status = EscrowStatus::Cancelled;

    msg!(
        "Escrow cancelled. {} milestones were approved. {} USDC refunded to client.",
        escrow.milestones_approved,
        refund_amount
    );

    Ok(())
}

#[derive(Accounts)]
pub struct CancelEscrow<'info> {
    #[account(mut)]
    pub client: Signer<'info>,

    #[account(
        mut,
        seeds = [ESCROW_SEED, client.key().as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        mut,
        seeds = [VAULT_SEED, escrow.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub client_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}
