use anchor_lang::prelude::*;
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<CreateMilestone>,
    milestone_index: u8,
    amount: u64,
    description: String,
) -> Result<()> {
    let escrow = &ctx.accounts.escrow;
    let milestone = &mut ctx.accounts.milestone;

    // Escrow must be Open or InProgress
    require!(
        escrow.status == EscrowStatus::Open
            || escrow.status == EscrowStatus::InProgress,
        EscrowError::InvalidEscrowStatus
    );

    // Only client can create milestones
    require!(
        ctx.accounts.client.key() == escrow.client,
        EscrowError::UnauthorizedClient
    );

    // Validate milestone index
    require!(
        milestone_index < escrow.milestone_count,
        EscrowError::InvalidMilestoneIndex
    );

    // Validate description length
    require!(
        description.len() <= MAX_DESCRIPTION_LEN,
        EscrowError::InvalidMilestoneIndex
    );

    // Validate amount
    require!(amount > 0, EscrowError::AmountMismatch);

    // Set milestone fields
    milestone.escrow = escrow.key();
    milestone.index = milestone_index;
    milestone.amount = amount;
    milestone.description = description;
    milestone.status = MilestoneStatus::Pending;
    milestone.submitted_at = None;
    milestone.approved_at = None;
    milestone.bump = ctx.bumps.milestone;

    msg!(
        "Milestone {} created with {} USDC.",
        milestone_index,
        amount
    );
    Ok(())
}

#[derive(Accounts)]
#[instruction(milestone_index: u8)]
pub struct CreateMilestone<'info> {
    #[account(mut)]
    pub client: Signer<'info>,

    #[account(
        seeds = [ESCROW_SEED, client.key().as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        init,
        payer = client,
        space = MilestoneAccount::LEN,
        seeds = [
            MILESTONE_SEED,
            escrow.key().as_ref(),
            &[milestone_index]
        ],
        bump
    )]
    pub milestone: Account<'info, MilestoneAccount>,

    pub system_program: Program<'info, System>,
}
