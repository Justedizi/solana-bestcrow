use anchor_lang::prelude::*;
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(ctx: Context<AcceptJob>) -> Result<()> {
    let escrow = &mut ctx.accounts.escrow;

    // Only accept if escrow is still Open
    require!(
        escrow.status == EscrowStatus::Open,
        EscrowError::InvalidEscrowStatus
    );

    // Only the designated freelancer can accept
    require!(
        ctx.accounts.freelancer.key() == escrow.freelancer,
        EscrowError::UnauthorizedFreelancer
    );

    // Update escrow status to InProgress
    escrow.status = EscrowStatus::InProgress;

    msg!("Job accepted by freelancer. Work has begun.");
    Ok(())
}

#[derive(Accounts)]
pub struct AcceptJob<'info> {
    #[account(mut)]
    pub freelancer: Signer<'info>,

    #[account(
        mut,
        seeds = [ESCROW_SEED, escrow.client.as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    pub system_program: Program<'info, System>,
}
