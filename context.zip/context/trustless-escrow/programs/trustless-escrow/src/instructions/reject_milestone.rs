use anchor_lang::prelude::*;
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<RejectMilestone>,
    milestone_index: u8,
) -> Result<()> {
    let escrow = &ctx.accounts.escrow;
    let milestone = &mut ctx.accounts.milestone;

    // Escrow must be InProgress
    require!(
        escrow.status == EscrowStatus::InProgress,
        EscrowError::InvalidEscrowStatus
    );

    // Only the client can reject
    require!(
        ctx.accounts.client.key() == escrow.client,
        EscrowError::UnauthorizedClient
    );

    // Milestone must be Submitted to be rejected
    require!(
        milestone.status == MilestoneStatus::Submitted,
        EscrowError::InvalidMilestoneStatus
    );

    // Send milestone back to InProgress for revision
    milestone.status = MilestoneStatus::InProgress;
    milestone.submitted_at = None;

    msg!(
        "Milestone {} rejected by client. Freelancer must revise and resubmit.",
        milestone_index
    );
    Ok(())
}

#[derive(Accounts)]
#[instruction(milestone_index: u8)]
pub struct RejectMilestone<'info> {
    #[account(mut)]
    pub client: Signer<'info>,

    #[account(
        seeds = [ESCROW_SEED, client.key().as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        mut,
        seeds = [
            MILESTONE_SEED,
            escrow.key().as_ref(),
            &[milestone_index]
        ],
        bump = milestone.bump
    )]
    pub milestone: Account<'info, MilestoneAccount>,

    pub system_program: Program<'info, System>,
}
