use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<ApproveMilestone>,
    milestone_index: u8,
) -> Result<()> {
    let escrow = &mut ctx.accounts.escrow;
    let milestone = &mut ctx.accounts.milestone;
    let clock = Clock::get()?;

    // Escrow must be InProgress
    require!(
        escrow.status == EscrowStatus::InProgress,
        EscrowError::InvalidEscrowStatus
    );

    // Only the client can approve
    require!(
        ctx.accounts.client.key() == escrow.client,
        EscrowError::UnauthorizedClient
    );

    // Milestone must be Submitted
    require!(
        milestone.status == MilestoneStatus::Submitted,
        EscrowError::InvalidMilestoneStatus
    );

    // Release USDC from vault to freelancer
    // Note: Since vault authority is set to escrow in initialize, we use escrow PDA seeds as signer
    let client_key = escrow.client;
    let seeds = &[
        ESCROW_SEED,
        client_key.as_ref(),
        &[escrow.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    let transfer_ctx = CpiContext::new_with_signer(
        ctx.accounts.token_program.key(),
        Transfer {
            from: ctx.accounts.vault.to_account_info(),
            to: ctx.accounts.freelancer_token_account.to_account_info(),
            authority: escrow.to_account_info(),
        },
        signer_seeds,
    );
    token::transfer(transfer_ctx, milestone.amount)?;

    // Update milestone status
    milestone.status = MilestoneStatus::Approved;
    milestone.approved_at = Some(clock.unix_timestamp);

    // Update escrow approved count
    escrow.milestones_approved += 1;

    // If all milestones approved — mark job as Completed
    if escrow.milestones_approved == escrow.milestone_count {
        escrow.status = EscrowStatus::Completed;
        msg!("All milestones approved. Job completed!");
    } else {
        msg!(
            "Milestone {} approved. {} USDC released to freelancer.",
            milestone_index,
            milestone.amount
        );
    }

    Ok(())
}

#[derive(Accounts)]
#[instruction(milestone_index: u8)]
pub struct ApproveMilestone<'info> {
    #[account(mut)]
    pub client: Signer<'info>,

    #[account(
        mut,
        seeds = [ESCROW_SEED, client.key().as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        mut,
        seeds = [
            MILESTONE_SEED,
            escrow.key().as_ref(),
            &[milestone_index]
        ],
        bump = milestone.bump
    )]
    pub milestone: Account<'info, MilestoneAccount>,

    // Vault PDA holding the locked USDC
    #[account(
        mut,
        seeds = [VAULT_SEED, escrow.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, TokenAccount>,

    // Freelancer's USDC token account (receives payment)
    #[account(mut)]
    pub freelancer_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}
