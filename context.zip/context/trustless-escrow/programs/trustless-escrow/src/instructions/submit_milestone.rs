use anchor_lang::prelude::*;
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<SubmitMilestone>,
    milestone_index: u8,
) -> Result<()> {
    let escrow = &ctx.accounts.escrow;
    let milestone = &mut ctx.accounts.milestone;
    let clock = Clock::get()?;

    // Escrow must be InProgress
    require!(
        escrow.status == EscrowStatus::InProgress,
        EscrowError::InvalidEscrowStatus
    );

    // Only the designated freelancer can submit
    require!(
        ctx.accounts.freelancer.key() == escrow.freelancer,
        EscrowError::UnauthorizedFreelancer
    );

    // Milestone must be InProgress or Pending
    require!(
        milestone.status == MilestoneStatus::InProgress
            || milestone.status == MilestoneStatus::Pending,
        EscrowError::InvalidMilestoneStatus
    );

    // Validate milestone index
    require!(
        milestone_index < escrow.milestone_count,
        EscrowError::InvalidMilestoneIndex
    );

    // Update milestone status to Submitted
    milestone.status = MilestoneStatus::Submitted;
    milestone.submitted_at = Some(clock.unix_timestamp);

    msg!(
        "Milestone {} submitted by freelancer. Awaiting client review.",
        milestone_index
    );
    Ok(())
}

#[derive(Accounts)]
#[instruction(milestone_index: u8)]
pub struct SubmitMilestone<'info> {
    #[account(mut)]
    pub freelancer: Signer<'info>,

    #[account(
        seeds = [ESCROW_SEED, escrow.client.as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        mut,
        seeds = [
            MILESTONE_SEED,
            escrow.key().as_ref(),
            &[milestone_index]
        ],
        bump = milestone.bump
    )]
    pub milestone: Account<'info, MilestoneAccount>,

    pub system_program: Program<'info, System>,
}
