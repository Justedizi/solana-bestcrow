use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<ResolveDispute>,
    _milestone_index: u8,
    resolution: DisputeResolution,
) -> Result<()> {
    let escrow = &mut ctx.accounts.escrow;
    let milestone = &mut ctx.accounts.milestone;
    let dispute = &mut ctx.accounts.dispute;
    let clock = Clock::get()?;

    // Escrow must be Disputed
    require!(
        escrow.status == EscrowStatus::Disputed,
        EscrowError::InvalidEscrowStatus
    );

    // Only the arbitrator can resolve
    require!(
        ctx.accounts.arbitrator.key() == escrow.arbitrator,
        EscrowError::UnauthorizedArbitrator
    );

    // Milestone must be Disputed
    require!(
        milestone.status == MilestoneStatus::Disputed,
        EscrowError::InvalidMilestoneStatus
    );

    let milestone_amount = milestone.amount;
    let seeds = &[
        ESCROW_SEED,
        escrow.client.as_ref(),
        &[escrow.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    match &resolution {
        DisputeResolution::FreelancerWins => {
            // Full amount goes to freelancer
            let transfer_ctx = CpiContext::new_with_signer(
                ctx.accounts.token_program.key(),
                Transfer {
                    from: ctx.accounts.vault.to_account_info(),
                    to: ctx.accounts.freelancer_token_account.to_account_info(),
                    authority: escrow.to_account_info(),
                },
                signer_seeds,
            );
            token::transfer(transfer_ctx, milestone_amount)?;
            milestone.status = MilestoneStatus::ResolvedForFreelancer;
            msg!("Dispute resolved. Freelancer wins. Full amount released.");
        }

        DisputeResolution::ClientWins => {
            // Full amount refunded to client
            let transfer_ctx = CpiContext::new_with_signer(
                ctx.accounts.token_program.key(),
                Transfer {
                    from: ctx.accounts.vault.to_account_info(),
                    to: ctx.accounts.client_token_account.to_account_info(),
                    authority: escrow.to_account_info(),
                },
                signer_seeds,
            );
            token::transfer(transfer_ctx, milestone_amount)?;
            milestone.status = MilestoneStatus::ResolvedForClient;
            msg!("Dispute resolved. Client wins. Full amount refunded.");
        }

        DisputeResolution::Split(freelancer_percentage) => {
            // Validate percentage
            require!(
                *freelancer_percentage <= 100,
                EscrowError::InvalidSplitPercentage
            );

            // Calculate split amounts
            let freelancer_amount = (milestone_amount as u128)
                .checked_mul(*freelancer_percentage as u128)
                .unwrap()
                .checked_div(100)
                .unwrap() as u64;

            let client_amount = milestone_amount
                .checked_sub(freelancer_amount)
                .unwrap();

            // Transfer freelancer portion
            if freelancer_amount > 0 {
                let transfer_ctx = CpiContext::new_with_signer(
                    ctx.accounts.token_program.key(),
                    Transfer {
                        from: ctx.accounts.vault.to_account_info(),
                        to: ctx.accounts.freelancer_token_account.to_account_info(),
                        authority: escrow.to_account_info(),
                    },
                    signer_seeds,
                );
                token::transfer(transfer_ctx, freelancer_amount)?;
            }

            // Transfer client portion
            if client_amount > 0 {
                let transfer_ctx = CpiContext::new_with_signer(
                    ctx.accounts.token_program.key(),
                    Transfer {
                        from: ctx.accounts.vault.to_account_info(),
                        to: ctx.accounts.client_token_account.to_account_info(),
                        authority: escrow.to_account_info(),
                    },
                    signer_seeds,
                );
                token::transfer(transfer_ctx, client_amount)?;
            }

            milestone.status = MilestoneStatus::ResolvedForFreelancer;
            msg!(
                "Dispute resolved. Split {}% freelancer / {}% client.",
                freelancer_percentage,
                100 - freelancer_percentage
            );
        }
    }

    // Update dispute record
    dispute.resolution = Some(resolution);
    dispute.resolved_at = Some(clock.unix_timestamp);

    // Resume escrow back to InProgress
    escrow.status = EscrowStatus::InProgress;
    escrow.milestones_approved += 1;

    // Check if all milestones are now done
    if escrow.milestones_approved == escrow.milestone_count {
        escrow.status = EscrowStatus::Completed;
        msg!("All milestones resolved. Job completed.");
    }

    Ok(())
}

#[derive(Accounts)]
#[instruction(milestone_index: u8)]
pub struct ResolveDispute<'info> {
    #[account(mut)]
    pub arbitrator: Signer<'info>,

    #[account(
        mut,
        seeds = [ESCROW_SEED, escrow.client.as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        mut,
        seeds = [
            MILESTONE_SEED,
            escrow.key().as_ref(),
            &[milestone_index]
        ],
        bump = milestone.bump
    )]
    pub milestone: Account<'info, MilestoneAccount>,

    #[account(
        mut,
        seeds = [
            DISPUTE_SEED,
            escrow.key().as_ref(),
            milestone.key().as_ref()
        ],
        bump = dispute.bump
    )]
    pub dispute: Account<'info, DisputeAccount>,

    #[account(
        mut,
        seeds = [VAULT_SEED, escrow.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub freelancer_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub client_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}
