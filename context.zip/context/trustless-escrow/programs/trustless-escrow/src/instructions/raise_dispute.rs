use anchor_lang::prelude::*;
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<RaiseDispute>,
    milestone_index: u8,
    reason: String,
) -> Result<()> {
    let escrow = &mut ctx.accounts.escrow;
    let milestone = &mut ctx.accounts.milestone;
    let dispute = &mut ctx.accounts.dispute;

    // Escrow must be InProgress
    require!(
        escrow.status == EscrowStatus::InProgress,
        EscrowError::InvalidEscrowStatus
    );

    // Only client or freelancer can raise a dispute
    let caller = ctx.accounts.caller.key();
    require!(
        caller == escrow.client || caller == escrow.freelancer,
        EscrowError::UnauthorizedClient
    );

    // Milestone must be Submitted or InProgress
    require!(
        milestone.status == MilestoneStatus::Submitted
            || milestone.status == MilestoneStatus::InProgress,
        EscrowError::InvalidMilestoneStatus
    );

    // Validate reason length
    require!(
        reason.len() <= MAX_REASON_LEN,
        EscrowError::InvalidMilestoneStatus
    );

    // Set dispute details
    dispute.escrow = escrow.key();
    dispute.milestone = milestone.key();
    dispute.raised_by = caller;
    dispute.reason = reason;
    dispute.resolution = None;
    dispute.resolved_at = None;
    dispute.bump = ctx.bumps.dispute;

    // Freeze milestone and escrow
    milestone.status = MilestoneStatus::Disputed;
    escrow.status = EscrowStatus::Disputed;

    msg!(
        "Dispute raised on milestone {} by {}. Funds frozen pending arbitration.",
        milestone_index,
        caller
    );
    Ok(())
}

#[derive(Accounts)]
#[instruction(milestone_index: u8, reason: String)]
pub struct RaiseDispute<'info> {
    #[account(mut)]
    pub caller: Signer<'info>,

    #[account(
        mut,
        seeds = [ESCROW_SEED, escrow.client.as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        mut,
        seeds = [
            MILESTONE_SEED,
            escrow.key().as_ref(),
            &[milestone_index]
        ],
        bump = milestone.bump
    )]
    pub milestone: Account<'info, MilestoneAccount>,

    // Dispute PDA — created fresh for this dispute
    #[account(
        init,
        payer = caller,
        space = DisputeAccount::LEN,
        seeds = [
            DISPUTE_SEED,
            escrow.key().as_ref(),
            milestone.key().as_ref()
        ],
        bump
    )]
    pub dispute: Account<'info, DisputeAccount>,

    pub system_program: Program<'info, System>,
}
