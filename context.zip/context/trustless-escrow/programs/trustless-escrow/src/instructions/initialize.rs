use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<InitializeEscrow>,
    freelancer: Pubkey,
    arbitrator: Pubkey,
    total_amount: u64,
    milestone_count: u8,
) -> Result<()> {
    // Validate milestone count
    require!(
        milestone_count > 0 && milestone_count <= MAX_MILESTONES,
        EscrowError::InvalidMilestoneIndex
    );

    // Validate total amount
    require!(total_amount > 0, EscrowError::AmountMismatch);

    let escrow = &mut ctx.accounts.escrow;
    let clock = Clock::get()?;

    // Set all escrow fields
    escrow.client = ctx.accounts.client.key();
    escrow.freelancer = freelancer;
    escrow.arbitrator = arbitrator;
    escrow.total_amount = total_amount;
    escrow.milestone_count = milestone_count;
    escrow.milestones_approved = 0;
    escrow.status = EscrowStatus::Open;
    escrow.created_at = clock.unix_timestamp;
    escrow.bump = ctx.bumps.escrow;

    // Transfer USDC from client wallet into program vault
    let transfer_ctx = CpiContext::new(
        ctx.accounts.token_program.key(),
        Transfer {
            from: ctx.accounts.client_token_account.to_account_info(),
            to: ctx.accounts.vault.to_account_info(),
            authority: ctx.accounts.client.to_account_info(),
        },
    );
    token::transfer(transfer_ctx, total_amount)?;

    msg!("Escrow initialized. {} USDC locked in vault.", total_amount);
    Ok(())
}

#[derive(Accounts)]
pub struct InitializeEscrow<'info> {
    #[account(mut)]
    pub client: Signer<'info>,

    // The escrow PDA account
    #[account(
        init,
        payer = client,
        space = EscrowAccount::LEN,
        seeds = [ESCROW_SEED, client.key().as_ref()],
        bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    // The vault PDA that holds the locked USDC
    #[account(
        init,
        payer = client,
        token::mint = usdc_mint,
        token::authority = escrow,
        seeds = [VAULT_SEED, escrow.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, TokenAccount>,

    // Client's USDC token account (where funds come from)
    #[account(mut)]
    pub client_token_account: Account<'info, TokenAccount>,

    /// CHECK: USDC mint address
    pub usdc_mint: UncheckedAccount<'info>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}
