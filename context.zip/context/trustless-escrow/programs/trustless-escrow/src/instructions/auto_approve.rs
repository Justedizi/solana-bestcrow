use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};
use crate::state::*;
use crate::constants::*;
use crate::error::EscrowError;

pub fn handler(
    ctx: Context<AutoApprove>,
    milestone_index: u8,
) -> Result<()> {
    let escrow = &mut ctx.accounts.escrow;
    let milestone = &mut ctx.accounts.milestone;
    let clock = Clock::get()?;

    // Escrow must be InProgress
    require!(
        escrow.status == EscrowStatus::InProgress,
        EscrowError::InvalidEscrowStatus
    );

    // Milestone must be Submitted
    require!(
        milestone.status == MilestoneStatus::Submitted,
        EscrowError::InvalidMilestoneStatus
    );

    // Get submission timestamp
    let submitted_at = milestone.submitted_at
        .ok_or(EscrowError::InvalidMilestoneStatus)?;

    let time_elapsed = clock.unix_timestamp - submitted_at;

    // 48-hour dispute window — client's last chance to raise dispute
    // Auto-approve only triggers AFTER full 7 days
    // Timeline:
    // Day 0:   Freelancer submits
    // Day 1-5: Client reviews normally
    // Day 5-7: Warning period — client must dispute or approve
    // Day 7+:  Auto-approve triggers if no action taken
    require!(
        time_elapsed >= AUTO_APPROVE_SECONDS,
        EscrowError::TimeLockNotExpired
    );

    // Check no active dispute exists on this milestone
    // If client raised dispute during warning period, auto-approve is blocked
    require!(
        milestone.status != MilestoneStatus::Disputed,
        EscrowError::DisputeAlreadyExists
    );

    // Release USDC from vault to freelancer
    let seeds = &[
        ESCROW_SEED,
        escrow.client.as_ref(),
        &[escrow.bump],
    ];
    let signer_seeds = &[&seeds[..]];

    let transfer_ctx = CpiContext::new_with_signer(
        ctx.accounts.token_program.key(),
        Transfer {
            from: ctx.accounts.vault.to_account_info(),
            to: ctx.accounts.freelancer_token_account.to_account_info(),
            authority: escrow.to_account_info(),
        },
        signer_seeds,
    );
    token::transfer(transfer_ctx, milestone.amount)?;

    // Update milestone status
    milestone.status = MilestoneStatus::Approved;
    milestone.approved_at = Some(clock.unix_timestamp);

    // Update escrow approved count
    escrow.milestones_approved += 1;

    // Check if all milestones completed
    if escrow.milestones_approved == escrow.milestone_count {
        escrow.status = EscrowStatus::Completed;
        msg!("All milestones completed. Job done!");
    } else {
        msg!(
            "Milestone {} auto-approved after 7 days. {} USDC released to freelancer.",
            milestone_index,
            milestone.amount
        );
    }

    Ok(())
}

#[derive(Accounts)]
#[instruction(milestone_index: u8)]
pub struct AutoApprove<'info> {
    /// CHECK: Anyone can trigger auto-approve after time lock expires
    pub caller: Signer<'info>,

    #[account(
        mut,
        seeds = [ESCROW_SEED, escrow.client.as_ref()],
        bump = escrow.bump
    )]
    pub escrow: Account<'info, EscrowAccount>,

    #[account(
        mut,
        seeds = [
            MILESTONE_SEED,
            escrow.key().as_ref(),
            &[milestone_index]
        ],
        bump = milestone.bump
    )]
    pub milestone: Account<'info, MilestoneAccount>,

    #[account(
        mut,
        seeds = [VAULT_SEED, escrow.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, TokenAccount>,

    #[account(mut)]
    pub freelancer_token_account: Account<'info, TokenAccount>,

    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}
