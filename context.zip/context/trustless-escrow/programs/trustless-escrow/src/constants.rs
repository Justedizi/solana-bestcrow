// Maximum number of milestones allowed per escrow
pub const MAX_MILESTONES: u8 = 10;

// Maximum characters allowed in milestone description
pub const MAX_DESCRIPTION_LEN: usize = 1000;

// Maximum characters allowed in dispute reason
pub const MAX_REASON_LEN: usize = 500;

// Auto-approve time lock in seconds (7 days)
// If client doesn't respond to submission in 7 days, milestone auto-approves
pub const AUTO_APPROVE_SECONDS: i64 = 7 * 24 * 60 * 60;

// 48-hour dispute warning window in seconds
pub const DISPUTE_WINDOW_SECONDS: i64 = 2 * 24 * 60 * 60;

// PDA seeds
pub const ESCROW_SEED: &[u8] = b"escrow";
pub const MILESTONE_SEED: &[u8] = b"milestone";
pub const DISPUTE_SEED: &[u8] = b"dispute";
pub const VAULT_SEED: &[u8] = b"vault";
