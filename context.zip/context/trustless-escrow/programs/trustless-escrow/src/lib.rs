pub mod constants;
pub mod error;
pub mod instructions;
pub mod state;

use anchor_lang::prelude::*;

pub use constants::*;
pub use instructions::*;
pub use instructions::{
    initialize, accept_job, submit_milestone, approve_milestone, reject_milestone,
    raise_dispute, resolve_dispute, cancel_escrow, auto_approve, create_milestone,
};
pub(crate) use instructions::initialize::__client_accounts_initialize_escrow;
pub(crate) use instructions::accept_job::__client_accounts_accept_job;
pub(crate) use instructions::submit_milestone::__client_accounts_submit_milestone;
pub(crate) use instructions::approve_milestone::__client_accounts_approve_milestone;
pub(crate) use instructions::reject_milestone::__client_accounts_reject_milestone;
pub(crate) use instructions::raise_dispute::__client_accounts_raise_dispute;
pub(crate) use instructions::resolve_dispute::__client_accounts_resolve_dispute;
pub(crate) use instructions::cancel_escrow::__client_accounts_cancel_escrow;
pub(crate) use instructions::auto_approve::__client_accounts_auto_approve;
pub(crate) use instructions::create_milestone::__client_accounts_create_milestone;
pub use state::*;

declare_id!("F238Azgqsx3tSXZjhQsz5DeekE4DWqHTj2LFimxUixx7");

#[program]
pub mod trustless_escrow {
    use super::*;

    pub fn initialize(
        ctx: Context<InitializeEscrow>,
        freelancer: Pubkey,
        arbitrator: Pubkey,
        total_amount: u64,
        milestone_count: u8,
    ) -> Result<()> {
        initialize::handler(ctx, freelancer, arbitrator, total_amount, milestone_count)
    }

    pub fn accept_job(ctx: Context<AcceptJob>) -> Result<()> {
        accept_job::handler(ctx)
    }

    pub fn submit_milestone(ctx: Context<SubmitMilestone>, milestone_index: u8) -> Result<()> {
        submit_milestone::handler(ctx, milestone_index)
    }

    pub fn approve_milestone(ctx: Context<ApproveMilestone>, milestone_index: u8) -> Result<()> {
        approve_milestone::handler(ctx, milestone_index)
     }

    pub fn reject_milestone(ctx: Context<RejectMilestone>, milestone_index: u8) -> Result<()> {
        reject_milestone::handler(ctx, milestone_index)
    }

    pub fn raise_dispute(ctx: Context<RaiseDispute>, milestone_index: u8, reason: String) -> Result<()> {
        raise_dispute::handler(ctx, milestone_index, reason)
    }

    pub fn resolve_dispute(ctx: Context<ResolveDispute>, milestone_index: u8, resolution: DisputeResolution) -> Result<()> {
        resolve_dispute::handler(ctx, milestone_index, resolution)
    }

    pub fn cancel_escrow(ctx: Context<CancelEscrow>) -> Result<()> {
        cancel_escrow::handler(ctx)
    }

    pub fn auto_approve(ctx: Context<AutoApprove>, milestone_index: u8) -> Result<()> {
        auto_approve::handler(ctx, milestone_index)
    }

    pub fn create_milestone(
        ctx: Context<CreateMilestone>,
        milestone_index: u8,
        amount: u64,
        description: String,
    ) -> Result<()> {
        create_milestone::handler(ctx, milestone_index, amount, description)
    }
}
