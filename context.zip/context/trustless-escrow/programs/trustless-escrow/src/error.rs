use anchor_lang::prelude::*;

#[error_code]
pub enum EscrowError {
    #[msg("Only the client can perform this action")]
    UnauthorizedClient,

    #[msg("Only the freelancer can perform this action")]
    UnauthorizedFreelancer,

    #[msg("Only the arbitrator can perform this action")]
    UnauthorizedArbitrator,

    #[msg("Escrow is not in the correct status for this action")]
    InvalidEscrowStatus,

    #[msg("Milestone is not in the correct status for this action")]
    InvalidMilestoneStatus,

    #[msg("Milestone index out of range")]
    InvalidMilestoneIndex,

    #[msg("Total milestone amounts must equal escrow total amount")]
    AmountMismatch,

    #[msg("Escrow has already been cancelled")]
    EscrowCancelled,

    #[msg("Escrow has already been completed")]
    EscrowCompleted,

    #[msg("Cannot cancel escrow after milestones have been approved")]
    CannotCancelAfterApproval,

    #[msg("Dispute already exists for this milestone")]
    DisputeAlreadyExists,

    #[msg("No dispute exists for this milestone")]
    NoDisputeExists,

    #[msg("Split percentage must be between 0 and 100")]
    InvalidSplitPercentage,

    #[msg("Auto-approve time lock has not expired yet")]
    TimeLockNotExpired,
}
