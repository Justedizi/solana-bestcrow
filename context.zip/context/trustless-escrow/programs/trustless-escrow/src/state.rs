use anchor_lang::prelude::*;

// ── Escrow Account ──
// The main contract that holds all job details
#[account]
pub struct EscrowAccount {
    pub client: Pubkey,           // wallet that created and funded the job
    pub freelancer: Pubkey,       // wallet that will do the work
    pub arbitrator: Pubkey,       // trusted third party for disputes
    pub total_amount: u64,        // total USDC locked for this job
    pub milestone_count: u8,      // how many milestones this job has
    pub milestones_approved: u8,  // how many milestones completed so far
    pub status: EscrowStatus,     // current state of the job
    pub created_at: i64,          // unix timestamp when job was created
    pub bump: u8,                 // PDA bump seed
}

// ── Milestone Account ──
// One account per milestone — tracks each piece of work
#[account]
pub struct MilestoneAccount {
    pub escrow: Pubkey,           // which job this milestone belongs to
    pub index: u8,                // milestone number (0, 1, 2...)
    pub amount: u64,              // USDC amount for this milestone
    pub description: String,      // what needs to be delivered
    pub status: MilestoneStatus,  // current state of this milestone
    pub submitted_at: Option<i64>,// when freelancer submitted work
    pub approved_at: Option<i64>, // when client approved work
    pub bump: u8,                 // PDA bump seed
}

// ── Dispute Account ──
// Created when either party raises a dispute on a milestone
#[account]
pub struct DisputeAccount {
    pub escrow: Pubkey,                    // which job the dispute is about
    pub milestone: Pubkey,                 // which milestone is disputed
    pub raised_by: Pubkey,                 // who raised the dispute
    pub reason: String,                    // why the dispute was raised
    pub resolution: Option<DisputeResolution>, // how it was resolved
    pub resolved_at: Option<i64>,          // when it was resolved
    pub bump: u8,                          // PDA bump seed
}

// ── Escrow Status ──
// All possible states a job can be in
#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum EscrowStatus {
    Open,        // job created, waiting for freelancer
    InProgress,  // freelancer accepted, work has started
    Completed,   // all milestones approved, job done
    Cancelled,   // job cancelled before any work started
    Disputed,    // active dispute on a milestone
}

// ── Milestone Status ──
// All possible states a milestone can be in
#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum MilestoneStatus {
    Pending,               // not started yet
    InProgress,            // freelancer is working on it
    Submitted,             // freelancer submitted, waiting for client review
    Approved,              // client approved, payment released
    Disputed,              // under dispute
    ResolvedForFreelancer, // dispute resolved — freelancer gets paid
    ResolvedForClient,     // dispute resolved — client gets refund
}

// ── Dispute Resolution ──
// How a dispute can be resolved
#[derive(AnchorSerialize, AnchorDeserialize, Clone, PartialEq)]
pub enum DisputeResolution {
    FreelancerWins,  // full milestone amount goes to freelancer
    ClientWins,      // full milestone amount refunded to client
    Split(u8),       // percentage goes to freelancer, rest to client
}

// ── Account Space Calculations ──
// Solana requires knowing exact account sizes upfront
impl EscrowAccount {
    pub const LEN: usize = 8   // discriminator
        + 32   // client pubkey
        + 32   // freelancer pubkey
        + 32   // arbitrator pubkey
        + 8    // total_amount
        + 1    // milestone_count
        + 1    // milestones_approved
        + 1    // status enum
        + 8    // created_at
        + 1;   // bump
}

impl MilestoneAccount {
    pub const LEN: usize = 8   // discriminator
        + 32   // escrow pubkey
        + 1    // index
        + 8    // amount
        + 4 + 1000  // description string (max 1000 chars)
        + 1    // status enum
        + 9    // submitted_at Option<i64>
        + 9    // approved_at Option<i64>
        + 1;   // bump
}

impl DisputeAccount {
    pub const LEN: usize = 8   // discriminator
        + 32   // escrow pubkey
        + 32   // milestone pubkey
        + 32   // raised_by pubkey
        + 4 + 500  // reason string (max 500 chars)
        + 2    // resolution Option<enum>
        + 9    // resolved_at Option<i64>
        + 1;   // bump
}
