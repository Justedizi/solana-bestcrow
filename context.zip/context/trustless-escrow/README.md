# Trustless Escrow — Freelance Milestone Payment System on Solana

A fully on-chain escrow program built with Rust and Anchor on Solana, enabling trustless milestone-based payments between clients and freelancers — with no middlemen, no payment disputes left unresolved, and no ghost clients.

---

## 🌍 The Real-World Problem

Freelance work is broken. Every day:

- Clients refuse to pay after work is delivered
- Freelancers disappear with advance payments
- Disputes go to PayPal, banks, or courts — slow, biased, and expensive
- No transparency on payment terms or delivery conditions

These problems exist because traditional freelance systems rely on **trust** and **centralized intermediaries** to enforce agreements. When trust breaks down, the system fails.

---

## ⛓️ How Solana Fixes This

This program leverages three core blockchain advantages:

**Permissionlessness** — Anyone can create or accept a job. No account approval, no geographic restriction, no bank required.

**Trustlessness** — Payment is locked in a Program Derived Address (PDA) vault before work begins. Neither party can touch it — only the program logic decides when funds move.

**Token Infrastructure** — USDC payments settle instantly on-chain per milestone approval, with no intermediary taking a cut.

---

## 🏗️ Architecture

### Actors

| Role | Description |
|------|-------------|
| **Client** | Creates the escrow, locks USDC, approves milestones |
| **Freelancer** | Accepts the job, submits milestone work |
| **Arbitrator** | Trusted third party that resolves disputes |

---

### On-Chain Accounts

#### EscrowAccount (PDA)
The main contract holding all job details.

```
- client: Pubkey
- freelancer: Pubkey
- arbitrator: Pubkey
- total_amount: u64        (total USDC locked)
- milestone_count: u8      (number of milestones)
- milestones_approved: u8  (completed milestones)
- status: EscrowStatus
- created_at: i64
- bump: u8
```

**PDA Seeds:** `[b"escrow", client_pubkey]`

---

#### MilestoneAccount (PDA)
One account per milestone, tracking each deliverable.

```
- escrow: Pubkey
- index: u8
- amount: u64
- description: String      (max 1000 chars)
- status: MilestoneStatus
- submitted_at: Option<i64>
- approved_at: Option<i64>
- bump: u8
```

**PDA Seeds:** `[b"milestone", escrow_pubkey, milestone_index]`

---

#### DisputeAccount (PDA)
Created when a dispute is raised on a milestone.

```
- escrow: Pubkey
- milestone: Pubkey
- raised_by: Pubkey
- reason: String           (max 500 chars)
- resolution: Option<DisputeResolution>
- resolved_at: Option<i64>
- bump: u8
```

**PDA Seeds:** `[b"dispute", escrow_pubkey, milestone_pubkey]`

---

#### Vault (PDA Token Account)
Holds all locked USDC for the duration of the job.

**PDA Seeds:** `[b"vault", escrow_pubkey]`

**Authority:** The EscrowAccount PDA — no human can access vault funds directly.

---

### How Traditional vs On-Chain Works

| Scenario | Traditional System | Trustless Escrow |
|----------|-------------------|-----------------|
| Payment guarantee | Client pays after — freelancer hopes | Funds locked before work starts |
| Dispute resolution | PayPal/bank/court — weeks | Arbitrator resolves on-chain instantly |
| Ghost client | Freelancer loses work | Auto-approve after 7 days |
| Bad freelancer | Client loses advance | Cancel before milestone 4, get refund |
| Transparency | Hidden terms | All conditions visible on-chain |
| Fees | 3–20% platform cut | ~$0.004 per transaction |

---

## ⚙️ Instructions

### 1. `initialize_escrow`
Client creates the job and locks total USDC into the vault PDA. Defines number of milestones, freelancer address, and arbitrator address.

### 2. `create_milestone`
Client defines each milestone — amount allocated and description of deliverable. Must be called once per milestone index before work begins.

### 3. `accept_job`
Freelancer accepts the escrow. Only the designated freelancer wallet can call this. Status moves from `Open` → `InProgress`.

### 4. `submit_milestone`
Freelancer marks a milestone as submitted for client review. Timestamp recorded on-chain.

### 5. `approve_milestone`
Client approves submitted milestone. USDC for that milestone transfers automatically from vault to freelancer wallet. If all milestones approved, escrow status → `Completed`.

### 6. `reject_milestone`
Client rejects submitted work. Milestone returns to `InProgress` for revision. No funds move.

### 7. `raise_dispute`
Either client or freelancer raises a dispute on a milestone. Funds frozen. Escrow status → `Disputed`. Must be raised before 7-day auto-approve triggers.

### 8. `resolve_dispute`
Only the arbitrator can call this. Three possible resolutions:
- `FreelancerWins` — full milestone amount to freelancer
- `ClientWins` — full milestone amount refunded to client
- `Split(u8)` — percentage split between both parties

### 9. `cancel_escrow`
Client cancels the job. Only available before the 4th milestone is approved. Remaining locked USDC (minus already-paid milestones) is refunded to client.

**Cancellation rules:**
| Milestones Approved | Can Cancel? | Refund |
|--------------------|-------------|--------|
| 0 | ✅ Yes | 100% |
| 1 | ✅ Yes | Remaining only |
| 2 | ✅ Yes | Remaining only |
| 3 | ✅ Yes | Remaining only |
| 4+ | ❌ Locked | None |

### 10. `auto_approve`
Anyone can trigger this if client hasn't responded to a submitted milestone in 7 days. Protects freelancers from ghost clients. Blocked if client raised a dispute during the warning period.

**Timeline:**
```
Day 0:   Freelancer submits milestone
Day 1-5: Client reviews normally
Day 5-7: Warning period — client must approve or dispute
Day 7+:  Auto-approve triggers if no action taken
```

---

## 📊 Milestone State Machine

```
Pending
  ↓ (freelancer submits)
Submitted
  ↓                      ↓                    ↓
Approved             Disputed             Rejected
  ↓                      ↓                    ↓
Payment          Arbitrator resolves     InProgress
releases              ↓           ↓      (revision)
              Freelancer      Client
                wins           wins
```

---

## ⚖️ Tradeoffs & Constraints

| Tradeoff | Decision | Reason |
|----------|----------|--------|
| Max 10 milestones | Hard cap enforced | Prevents bloated accounts and complexity |
| Fixed arbitrator at creation | Set once, cannot change | Prevents colluding parties from swapping arbitrator mid-dispute |
| Cancel locked after milestone 4 | Hard rule | If client approved 4 milestones, work quality is clearly acceptable |
| 7-day auto-approve | Fixed constant | Balances client review time vs freelancer payment protection |
| USDC only | SPL token | Stablecoin eliminates price volatility risk for freelancers |
| No partial milestone payments | All-or-nothing per milestone | Simplifies accounting and dispute resolution |

---

## 🚀 Deployment

**Network:** Solana Devnet

**Program ID:**
```
F238Azgqsx3tSXZjhQsz5DeekE4DWqHTj2LFimxUixx7
```

**Explorer:**
[View Program on Solana Explorer](https://explorer.solana.com/address/F238Azgqsx3tSXZjhQsz5DeekE4DWqHTj2LFimxUixx7?cluster=devnet)

---

## 📜 Devnet Transaction Links

| Transaction | Description | Link |
|-------------|-------------|------|
| Deployment | Program deployed on Devnet | [View](https://explorer.solana.com/tx/4TmnYWtjCwbSSRhQoG7vfwmXRtQumhZwKpAjMsJGon5HhjXtadadReFVsNAwAfRnp4ww1GKxyhP5mrhszuJq2UXp?cluster=devnet) |
| Transfer + Metadata | System transfer and metadata setup | [View](https://explorer.solana.com/tx/5tyQqRmCpNYD5ukqbWoR7XbUUVXo8di7y7rLMAx2XiGqogsWvKog5sFUe449dJb1RLFoF2KbhV32cKPnNbMJSRi?cluster=devnet) |
| IDL Metadata | IDL initialized on-chain | [View](https://explorer.solana.com/tx/5FZmkCCKSuxY7WwDsi3xbWJrqpF1CwEhyn1MaL9MASrVfdvLRYDFwPd1XP6QjamnxvNVrhTKyJEGGXpc2tsHqoxM?cluster=devnet) |

---

## 🧪 How to Test

### Prerequisites
```bash
rustc --version     # 1.96+
solana --version    # 4.0+
anchor --version    # 1.0.2+
```

### Setup
```bash
git clone https://github.com/YOUR_GITHUB/trustless-escrow
cd trustless-escrow
npm install
```

### Configure Devnet
```bash
solana config set --url devnet
solana airdrop 2
```

### Build
```bash
anchor build
```

### Run Tests
```bash
anchor test
```

### Deploy
```bash
anchor program deploy
```

---

## 📁 Project Structure

```
trustless-escrow/
├── programs/
│   └── trustless-escrow/
│       └── src/
│           ├── lib.rs
│           ├── constants.rs
│           ├── error.rs
│           ├── state.rs
│           └── instructions/
│               ├── initialize.rs
│               ├── create_milestone.rs
│               ├── accept_job.rs
│               ├── submit_milestone.rs
│               ├── approve_milestone.rs
│               ├── reject_milestone.rs
│               ├── raise_dispute.rs
│               ├── resolve_dispute.rs
│               ├── cancel_escrow.rs
│               └── auto_approve.rs
├── tests/
├── app/
├── Anchor.toml
└── README.md
```

---

## 👤 Author

Built by [@Beastytho_](https://x.com/Beastytho_) for the Superteam Poland — Build Everyday Real-World Systems as On-Chain Rust Programs Bounty.
